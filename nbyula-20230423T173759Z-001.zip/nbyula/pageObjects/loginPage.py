from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

class login:
    signin = "//span[normalize-space()='Sign In']"
    see_other_opt = "//a[@id='login-modal-continue-with-email']"
    username_textbox = "//input[@id='text-input-1']"
    password_textbox = "//input[@id='text-input-29']"
    username_continue_button = "//button[@id='login-custom']"
    login_button = "//button[@id='login-custom']"
    profile = "//div[contains(@class,'relative flex-shrink-0 rounded-full bg-gray-50 bg-cover bg-center h-10 w-10')]//img[contains(@class,'h-full w-full rounded-full object-cover')]"
    logout_button = "//div[1]//nav[1]//ul[7]//li[1]//button[1]"

    def __int__(self,driver):
        self.driver=driver

    def goto_signin(self):
        self.driver.find_element(By.XPATH, self.signin).click()

    def goto_see_other_options(self):
        self.driver.find_element(By.XPATH, self.see_other_opt).click()

    def set_username(self,username):
        self.driver.find_element(By.XPATH, self.username_textbox).clear()
        self.driver.find_element(By.XPATH, self.username_textbox).send_keys(username)

    def click_continue(self):
        self.driver.find_element(By.XPATH, self.username_continue_button).click()

    def set_password(self,password):
        self.driver.find_element(By.XPATH, self.password_textbox).clear()
        self.driver.find_element(By.XPATH, self.password_textbox).send_keys(password)

    def click_login(self):
        self.driver.find_element(By.XPATH, self.login_button).click()

    def click_profile(self):
        self.driver.find_element(By.XPATH, self.profile).click()

    def click_logout(self):
        self.driver.find_element(By.XPATH, self.logout_button).click()
