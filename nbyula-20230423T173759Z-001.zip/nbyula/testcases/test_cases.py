from selenium import webdriver
import pytest
from pageObjects.loginPage import login


class test_login_001:
    link = "https://nbl.one/gigs/listings/careers1/demo-talk-test-engineer-1"
    username = "" #enter username
    password = "" #eter password

    def test_homepage_title(self, setup):
        self.driver = setup
        self.driver.get(self.link)
        actual_title = self.driver.title
        self.driver.close()

        if (actual_title == ("Nbyula - Demo Talk  - Test Engineer by Careers@Nbyula")):
            assert True
        else:
            assert False

    def test_login(self, setup):
        self.driver = setup
        self.driver.get(self.link)
        self.lp = login(self.driver)
        self.lp.goto_signin()
        self.lp.goto_see_other_options()
        self.lp.set_username(self.username)
        self.lp.click_continue()
        self.lp.set_password(self.password)
        self.lp.click_login()
        actual_title = self.driver.title
        self.driver.close()
        if actual_title == "Nbyula - Demo Talk  - Test Engineer by Careers@Nbyula":
            assert True
        else:
            assert False

    def